//
//  ViewController.swift
//  UIControls
//
//  Created by user237598 on 1/21/24.
//

import UIKit

class ViewController: UIViewController {

    var counter = 0
    var modeInc = false
    @IBOutlet weak var txtNum: UILabel!
    
    @IBAction func btnInc(_ sender: Any) {
        if modeInc{
            counter += 2
        }else{
            counter += 1
        }
        txtNum.text = String(counter)
        
    }
    
    @IBAction func btnDec(_ sender: Any) {
        if modeInc{
            counter -= 2
        }else{
            counter -= 1
        }
        txtNum.text = String(counter)
    }
    
    @IBAction func btnReset(_ sender: Any) {
        counter = 0
        txtNum.text = String(counter)
        modeInc = false
    }
    
    @IBAction func btnAddValue(_ sender: Any) {
        modeInc = true
            }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

